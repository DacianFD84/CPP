#ifndef EIGEN_SPQRSUPPORT_MODULE_H
#error "Please include Eigen/SPQRSupport instead of including headers inside the src directory directly."
#endif
