#ifndef EIGEN_SPARSECHOLESKY_MODULE_H
#error "Please include Eigen/SparseCholesky instead of including headers inside the src directory directly."
#endif
